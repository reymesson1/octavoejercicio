export interface BsModalOptions {
    backdrop: string | boolean;
    keyboard: boolean;
}
