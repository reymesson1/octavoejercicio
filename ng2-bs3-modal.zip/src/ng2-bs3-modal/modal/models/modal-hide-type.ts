export enum BsModalHideType {
    Close,
    Dismiss,
    Backdrop,
    Keyboard,
    RouteChange,
    Destroy
}
