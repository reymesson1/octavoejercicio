import { BsModalHideType } from './modal-hide-type';

export interface BsModalHideEvent {
    event: Event;
    type: BsModalHideType;
}

