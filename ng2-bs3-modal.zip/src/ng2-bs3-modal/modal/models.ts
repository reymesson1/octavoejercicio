
export { BsModalHideEvent } from './models/modal-hide-event';
export { BsModalHideType } from './models/modal-hide-type';
export { BsModalOptions } from './models/modal-options';
export { BsModalSize } from './models/modal-size';
