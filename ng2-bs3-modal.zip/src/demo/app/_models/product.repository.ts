import { Injectable } from '@angular/core';
import { Product } from './product';
import { StaticDataSource } from './static.datasource';

@Injectable()
export class ProductRepository{

    private products: Product[] = [];
    private categories: string[] = [];

    constructor(private dataSource: StaticDataSource){

        dataSource.getProducts().subscribe(

            data => {
                this.products = data;
                this.categories = data.map(p => p.fname)
                    .filter((c, index, array) => array.indexOf(c) == index).sort();
            }
        )
    }

    getProducts(): Product[]{

        return this.products;            
    }

    getProduct(id: number): Product{
        return this.products.find(p => p.id == id)
    }


}