import { Injectable, Inject } from '@angular/core';
import { Product } from './product';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/observable/from";

@Injectable()
export class StaticDataSource{

    private products: Product[] = [

         new Product(1,"Juan", "Perez", "1234"),
         new Product(2,"Jose", "Perez", "4321"),
         new Product(3,"Mateo", "Mateo", "7654"),
         new Product(4,"Marcos", "Lucas", "9876"),
    ]

    getProducts(): Observable<Product[]>{
        return Observable.from([this.products]);
    }
}