import { Component } from '@angular/core';

@Component({
    selector: 'master',
    template: `
    <toolbar></toolbar>
    <div class="container">
        <master-search (jokeCreated)="addJoke($event)"></master-search>
        <div class="pull-right">
            <master-button></master-button>
        </div>
        <br/>
        <br/>
        <br/>
        <master-table [joke]=this.inputText></master-table>
    </div>
    `,
})
export class MasterComponent {
    
    private inputText : string;
    
    addJoke($event){
        //console.log($event);
        this.inputText = $event;
    }

    
}
