import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'master-edit',
    template: ` 
    <toolbar></toolbar>
    <div class="container">   
        <h3>Master Edit {{this.objectid}}</h3>
    <div>   
    `,
})

export class MasterEditComponent {

    private objectid: any;

    constructor(private route: ActivatedRoute){
        
        this.route.params.subscribe(params => this.objectid=params.edit)
    }
}