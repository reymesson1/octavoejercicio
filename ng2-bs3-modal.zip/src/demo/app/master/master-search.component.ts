import { Component, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'master-search',
    template: `    
    <div class="panel panel-default">
        <div class="panel-heading">
        Master Search
        </div>
        <div class="panel-body">
        <form>
        <div class="form-group">
           <label for="first_name">Search</label>
           <input ngModel="" (ngModelChange)="onChange(fname)" type="text" class="form-control" id="first_name" name="first_name" #fname>
        </div>
        <button type="submit" class="btn btn-default pull-right">Search</button>
     </form>
        </div>
    </div>
    `,
})
export class MasterSearchComponent {

    @Output() jokeCreated = new EventEmitter<string>();

    private fname: string = '';

    onChange(fname){        
        this.jokeCreated.emit(fname.value);
    }


}
