import { Component, ViewChild } from '@angular/core';

import { MasterSubjectService } from '../_services/master-subject.service';

import { MasterButtonComponent } from './master-button.component';

import { CompleterService, CompleterData } from 'ng2-completer';

@Component({
    selector: 'master-modal',
    template: `
    <form #myForm="ngForm" (ngSubmit)="onSubmit(fname,lname,casenumber)">
        <div class="form-group">
        <label for="first_name">First Name</label>
        <ng2-completer [inputClass]="'form-control'" name="firstname"  [(ngModel)]="searchStr" [datasource]="dataService" [minSearchLength]="0" #fname></ng2-completer>                
        </div>
        <div class="form-group">
        <label for="first_name">Last Name</label>
        <ng2-completer [inputClass]="'form-control'" name="firstname2"  [(ngModel)]="searchStr2" [datasource]="dataService" [minSearchLength]="0" #lname></ng2-completer>
        </div>
        <div class="form-group">
        <label for="first_name">Case Number</label>
        <input type="text" class="form-control" id="first_name" name="first_name" #casenumber>
        </div>
        <button type="submit" class="btn btn-default pull-right">Save</button>
    </form>
    `,
})
export class MasterModalComponent {

    @ViewChild("myForm") myForm;

    public product : Object;

    constructor(private service: MasterSubjectService, private button : MasterButtonComponent, private completerService: CompleterService){

        this.dataService = completerService.local(this.searchData, 'color', 'color');
    }
    
    protected searchStr: string;
    protected captain: string;
    protected dataService: CompleterData;
    protected searchData = [
      { color: 'red', value: '#f00' },
      { color: 'green', value: '#0f0' },
      { color: 'blue', value: '#00f' },
      { color: 'cyan', value: '#0ff' },
      { color: 'magenta', value: '#f0f' },
      { color: 'yellow', value: '#ff0' },
      { color: 'black', value: '#000' }
    ];
    protected captains = ['James T. Kirk', 'Benjamin Sisko', 'Jean-Luc Picard', 'Spock', 'Jonathan Archer', 'Hikaru Sulu', 'Christopher Pike', 'Rachel Garrett' ];

    onSubmit(fname,lname,casenumber){
        
        this.product = {

            "id": 4,
            "fname": fname.value,
            "lname": lname.value,
            "casenumber": casenumber.value
        }

        this.service.newEvent(this.product);

        this.button.modal.close();

        this.myForm.reset();

        fname.value = null;
        lname.value = null;
        casenumber.value = null;
    }
}
