import { Component, Input } from '@angular/core';

import { Product } from '../_models/product';

import { MasterSubjectService } from '../_services/master-subject.service';

import { ProductRepository } from '../_models/product.repository';

@Component({
    selector: 'master-table',
    template: `    
    <div class="panel panel-default">
        <div class="panel-heading">
        Master Table
        </div>
        <div class="panel-body">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Case Number</th>
                <th>Actions</th>
            </tr>
            </thead>            
            <tbody>
            <tr *ngFor="let product of transacions">
                <td>{{product.fname}}</td>
                <td>{{product.lname}}</td>
                <td>{{product.casenumber}}</td>                
                <td>
                    <a [routerLink]="['/master',product.id]" class="btn btn-default">Edit</a>
                    <button class="btn btn-default">Delete</button>
                </td>
            </tr>
            </tbody>
        </table>
        </div>
    </div>
    `    
})
export class MasterTableComponent {

    constructor(private service: MasterSubjectService, private repository: ProductRepository){        
    }
    
    @Input('joke') data: string;

    get transacions(): Product[]{
      
        let filtered;

        if(this.data){

            filtered = this.products.filter(p=>p.fname.indexOf(this.data) > -1);
            return filtered;
        }else{
            return this.products;
        }

    }

    ngOnInit(){        
        
        this.service.events$.forEach(event => this.products.unshift(event));        
    }

    get products(): Product[]{
        return this.repository.getProducts();
    }


}
