import { Component } from '@angular/core';

@Component({
    selector: 'detail',
    template: `
        <h3>Detail</h3>
    `,
})
export class DetailComponent {
}
