import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { BsModalModule } from '../../ng2-bs3-modal/ng2-bs3-modal';

import { routing } from './app.routes';
import { AppComponent } from './app.component';
import { ModalDemoComponent } from './modal-demo.component';
import { HelloComponent } from './hello.component';

import { fakeBackendProvider } from './_helpers/index';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions } from '@angular/http';

import { AlertComponent } from './_directives/index';
import { AuthGuard } from './_guards/index';
import { AlertService, AuthenticationService, UserService } from './_services/index';
import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './register/index';

import { ToolbarComponent } from './toolbar.component';

import { MasterComponent } from './master/master.component';
import { MasterSearchComponent } from './master/master-search.component';
import { MasterTableComponent } from './master/master-table.component';
import { MasterButtonComponent } from './master/master-button.component';
import { MasterModalComponent } from './master/master-modal.component';
import { MasterSubjectService } from './_services/master-subject.service';
import { MasterEditComponent } from './master/master-edit.component';
import { DetailComponent } from './detail/detail.component';

import { Ng2CompleterModule } from "ng2-completer";

import { StaticDataSource } from './_models/static.datasource';
import { ProductRepository } from './_models/product.repository';

@NgModule({
    declarations: [
        AppComponent,
        ModalDemoComponent,
        HelloComponent,
        AlertComponent,
        HomeComponent,
        LoginComponent,
        RegisterComponent,
        ToolbarComponent,
        MasterComponent,
        MasterSearchComponent,
        MasterTableComponent,
        MasterButtonComponent,
        MasterModalComponent,
        MasterEditComponent,
        DetailComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        BsModalModule,
        Ng2CompleterModule,
        routing
    ],
    providers: [
        AuthGuard,
        AlertService,
        AuthenticationService,
        UserService,
        MasterSubjectService,
        StaticDataSource,
        ProductRepository,

        // providers used to create fake backend
        fakeBackendProvider,
        MockBackend,
        BaseRequestOptions
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
