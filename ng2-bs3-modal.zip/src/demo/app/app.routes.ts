import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModalDemoComponent } from './modal-demo.component';
import { HelloComponent } from './hello.component';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './register/index';
import { AuthGuard } from './_guards/index';

import { MasterComponent } from './master/master.component';
import { DetailComponent } from './detail/detail.component';

import { MasterEditComponent } from './master/master-edit.component';

const routes: Routes = [
    { path: '', component: ModalDemoComponent, canActivate: [AuthGuard] },
    { path: 'hello', component: HelloComponent },

    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },

    { path: 'master', component: MasterComponent, canActivate: [AuthGuard]  },
    { path: 'detail', component: DetailComponent  },

    { path: 'master/:edit', component: MasterEditComponent, canActivate: [AuthGuard] },
    
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
